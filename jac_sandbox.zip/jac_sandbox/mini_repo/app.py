from logic import calculate_price

def run_app():
    price = calculate_price()
    print(f"The price is {price}")