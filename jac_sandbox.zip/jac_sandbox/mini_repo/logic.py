def calculate_price():
    return 100