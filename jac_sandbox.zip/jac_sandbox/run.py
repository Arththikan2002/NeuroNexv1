# The final, simplest script.

import os
from jaclang import jac_import

# --- Build Absolute Paths ---
script_dir = os.path.dirname(os.path.abspath(__file__))
module_to_load = "build"
base_directory = script_dir

# --- Call jac_import with positional arguments ---
# Pass the arguments directly without the 'target=' or 'base_path=' keywords.
build_module = jac_import(module_to_load, base_directory)

# --- Access the walker ---
builder = build_module.BuildGraph()

# --- Run the walker ---
my_code_graph = builder.build_from(os.path.join(script_dir, "mini_repo"))

# --- Print the results ---
print("Graph built successfully!")
print(f"Found {len(my_code_graph.nodes)} nodes.")
print(f"Found {len(my_code_graph.edges)} edges.")